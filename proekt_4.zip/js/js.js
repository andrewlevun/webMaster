
  
   /*$('body').flipLightBox
   ({ lightbox_flip_speed: 500, 
      lightbox_border_color: '#666666' 
   })*/

   $(document).ready(function(){
      $('.nivo-lightbox a').nivoLightbox({ effect: 'fade' });
      });
  
   